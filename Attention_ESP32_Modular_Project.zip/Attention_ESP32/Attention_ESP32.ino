/*
  ATTENTION - ESP32 + 0.96-inch SSD1306 OLED
  Board: ESP32 Dev Module
  OLED: I2C, 128x64, usually address 0x3C

  Wiring:
    OLED VCC -> ESP32 3V3
    OLED GND -> ESP32 GND
    OLED SDA -> GPIO 21
    OLED SCL -> GPIO 22

  Install libraries:
    - Adafruit GFX Library
    - Adafruit SSD1306
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "animations.h"

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define OLED_ADDR 0x3C
#define SDA_PIN 21
#define SCL_PIN 22

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

uint32_t sceneStart = 0;
uint32_t lastFrame = 0;
uint8_t scene = 0;

const uint32_t SCENE_DURATION = 6500; // milliseconds per scene
const uint16_t FRAME_MS = 45;         // animation refresh interval

void setup() {
  Wire.begin(SDA_PIN, SCL_PIN);

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    while (true) delay(100);
  }

  display.clearDisplay();
  display.setTextWrap(false);
  centeredText(display, "ESP32 OLED", 25, 1);
  display.display();
  delay(900);
  sceneStart = millis();
}

void loop() {
  uint32_t now = millis();
  if (now - lastFrame < FRAME_MS) return;
  lastFrame = now;

  uint32_t elapsed = now - sceneStart;
  if (elapsed >= SCENE_DURATION) {
    scene = (scene + 1) % 7;
    sceneStart = now;
    elapsed = 0;
  }

  display.clearDisplay();

  switch (scene) {
    case 0: sceneIntro(display, elapsed); break;
    case 1: sceneMemory(display, elapsed); break;
    case 2: scenePerfume(display, elapsed); break;
    case 3: sceneApart(display, elapsed); break;
    case 4: sceneBrokenHeart(display, elapsed); break;
    case 5: sceneAttention(display, elapsed); break;
    default: sceneFinal(display, elapsed); break;
  }

  display.display();
}
