ATTENTION — MODULAR ESP32 OLED PROJECT

FILES
- Attention_ESP32.ino : setup, display initialization, scene timing and main loop
- animations.h        : drawing helpers and all seven animation scenes

HARDWARE
- ESP32 Dev Module
- 0.96-inch I2C OLED, SSD1306, 128x64

WIRING
OLED VCC -> ESP32 3V3
OLED GND -> ESP32 GND
OLED SDA -> GPIO 21
OLED SCL -> GPIO 22

ARDUINO IDE
1. Install/select the ESP32 board package and choose "ESP32 Dev Module".
2. Install "Adafruit GFX Library".
3. Install "Adafruit SSD1306".
4. Keep both source files in the same sketch folder named Attention_ESP32.
5. Open Attention_ESP32.ino and upload.

DISPLAY ADDRESS
The sketch defaults to 0x3C. If your OLED module uses 0x3D, change OLED_ADDR in the .ino file.

SCENES
Title, memory photo, perfume bottle, two people moving apart, broken heart,
attention pulse, and closing message. These are original visual scenes inspired
by the song's themes; the supplied lyrics are not reproduced in the code.

TIMING
Change SCENE_DURATION (milliseconds) in the .ino file to change each scene's
duration. Change FRAME_MS to adjust refresh speed.
