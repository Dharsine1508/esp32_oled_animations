#pragma once
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>

// All animation scenes for the Attention ESP32 OLED project.
// Display object is declared in the main .ino file.

inline void centeredText(Adafruit_SSD1306 &display, const char *s, int y, uint8_t size=1) {
  display.setTextSize(size);
  display.setTextColor(SSD1306_WHITE);
  int16_t x1, y1; uint16_t w, h;
  display.getTextBounds(s, 0, y, &x1, &y1, &w, &h);
  display.setCursor((128 - w) / 2, y);
  display.print(s);
}

inline void drawHeart(Adafruit_SSD1306 &display, int x, int y, int r, bool filled) {
  if (filled) {
    display.fillCircle(x-r/2, y-r/3, r/2, SSD1306_WHITE);
    display.fillCircle(x+r/2, y-r/3, r/2, SSD1306_WHITE);
    display.fillTriangle(x-r, y-r/8, x+r, y-r/8, x, y+r, SSD1306_WHITE);
  } else {
    display.drawCircle(x-r/2, y-r/3, r/2, SSD1306_WHITE);
    display.drawCircle(x+r/2, y-r/3, r/2, SSD1306_WHITE);
    display.drawLine(x-r, y-r/8, x, y+r, SSD1306_WHITE);
    display.drawLine(x+r, y-r/8, x, y+r, SSD1306_WHITE);
    display.drawLine(x-r, y-r/8, x+r, y-r/8, SSD1306_WHITE);
  }
}

inline void drawPerson(Adafruit_SSD1306 &display, int x, int y, bool facingRight) {
  display.drawCircle(x, y, 5, SSD1306_WHITE);
  display.drawLine(x, y+5, x, y+22, SSD1306_WHITE);
  display.drawLine(x, y+10, x-7, y+17, SSD1306_WHITE);
  display.drawLine(x, y+10, x+7, y+17, SSD1306_WHITE);
  display.drawLine(x, y+22, x-6, y+31, SSD1306_WHITE);
  display.drawLine(x, y+22, x+6, y+31, SSD1306_WHITE);
  display.drawPixel(facingRight ? x+2 : x-2, y-1, SSD1306_WHITE);
}

inline void sceneIntro(Adafruit_SSD1306 &display, uint32_t t) {
  centeredText(display, "ATTENTION", 8, 2);
  centeredText(display, "an OLED story", 31, 1);
  drawHeart(display, 64, 52, 10 + (int)(3*sin(t/220.0)), false);
  for (int i=0; i<8; i++) {
    int x = (i*19 + (t/30)%128) % 128;
    display.drawPixel(x, (i*11+5)%60, SSD1306_WHITE);
  }
}

inline void sceneMemory(Adafruit_SSD1306 &display, uint32_t t) {
  centeredText(display, "OLD MEMORIES", 2);
  display.drawRoundRect(37, 15, 54, 39, 3, SSD1306_WHITE);
  display.drawRect(42, 20, 44, 28, SSD1306_WHITE);
  drawPerson(display, 57, 26, true);
  drawPerson(display, 72, 26, false);
  for (int i=0; i<5; i++) {
    int x = (i*27 + (t/35)%128) % 128;
    display.drawPixel(x, 12 + (i*7)%43, SSD1306_WHITE);
  }
}

inline void scenePerfume(Adafruit_SSD1306 &display, uint32_t t) {
  centeredText(display, "A FAMILIAR SCENT", 2);
  display.drawRoundRect(48, 23, 32, 34, 4, SSD1306_WHITE);
  display.drawRect(57, 16, 14, 7, SSD1306_WHITE);
  display.drawRect(60, 12, 8, 4, SSD1306_WHITE);
  display.drawLine(53, 30, 75, 30, SSD1306_WHITE);
  centeredText(display, "~", 16 + (t/180)%4, 1);
  for (int i=0; i<6; i++) {
    int x = 18 + ((i*19 + t/25) % 92);
    int y = 18 + (i*13)%35;
    display.drawPixel(x, y, SSD1306_WHITE);
  }
}

inline void sceneApart(Adafruit_SSD1306 &display, uint32_t t) {
  centeredText(display, "DRIFTING APART", 2);
  int shift = min(34, (int)(t/90));
  drawPerson(display, 44-shift/2, 19, true);
  drawPerson(display, 84+shift/2, 19, false);
  display.drawLine(64, 17, 64, 54, SSD1306_WHITE);
  for (int i=0; i<4; i++) display.drawPixel(58+(i%2)*12, 24+i*8, SSD1306_WHITE);
}

inline void sceneBrokenHeart(Adafruit_SSD1306 &display, uint32_t t) {
  centeredText(display, "HEART IN TWO", 2);
  int bob = (int)(3*sin(t/170.0));
  drawHeart(display, 64, 34+bob, 22, false);
  display.drawLine(65, 16+bob, 59, 27+bob, SSD1306_WHITE);
  display.drawLine(59, 27+bob, 67, 34+bob, SSD1306_WHITE);
  display.drawLine(67, 34+bob, 60, 45+bob, SSD1306_WHITE);
  display.drawLine(60, 45+bob, 64, 54+bob, SSD1306_WHITE);
}

inline void sceneAttention(Adafruit_SSD1306 &display, uint32_t t) {
  centeredText(display, "ATTENTION", 2, 2);
  int pulse = (int)(5 + 3*sin(t/130.0));
  display.drawCircle(64, 39, 12+pulse, SSD1306_WHITE);
  display.drawCircle(64, 39, 19+pulse, SSD1306_WHITE);
  drawHeart(display, 64, 39, 10, true);
  for (int i=0; i<8; i++) {
    float a = (t/250.0) + i*0.785;
    display.drawPixel(64+(int)(29*cos(a)), 39+(int)(22*sin(a)), SSD1306_WHITE);
  }
}

inline void sceneFinal(Adafruit_SSD1306 &display, uint32_t t) {
  centeredText(display, "MOVE ON", 5, 2);
  drawHeart(display, 64, 37, 18, false);
  display.drawLine(64, 18, 64, 55, SSD1306_WHITE);
  centeredText(display, "YOUR STORY CONTINUES", 57, 1);
  if ((t/350)%2 == 0) display.drawPixel(12, 12, SSD1306_WHITE);
  else display.drawPixel(116, 12, SSD1306_WHITE);
}
