/*
  ATTENTION - ESP32 + 0.96" SSD1306 OLED animation
  Display: 128x64, I2C address usually 0x3C
  Board: ESP32 Dev Module
  Libraries (Arduino Library Manager):
    - Adafruit GFX Library
    - Adafruit SSD1306

  Wiring (classic ESP32):
    OLED VCC -> 3V3
    OLED GND -> GND
    OLED SDA -> GPIO 21
    OLED SCL -> GPIO 22

  This is an original, lyric-free visual interpretation inspired by the
  themes of the song. It does not display the song's lyrics.
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define OLED_ADDR 0x3C
#define SDA_PIN 21
#define SCL_PIN 22

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

uint32_t sceneStart = 0;
uint8_t scene = 0;
const uint32_t SCENE_DURATION = 6500;
uint32_t lastFrame = 0;
const uint16_t FRAME_MS = 45;

void centeredText(const char *s, int y, uint8_t size=1) {
  display.setTextSize(size);
  display.setTextColor(SSD1306_WHITE);
  int16_t x1, y1; uint16_t w, h;
  display.getTextBounds(s, 0, y, &x1, &y1, &w, &h);
  display.setCursor((SCREEN_WIDTH - w) / 2, y);
  display.print(s);
}

void drawHeart(int x, int y, int r, bool filled) {
  // Compact heart outline/fill made from two circles and a triangle.
  if (filled) {
    display.fillCircle(x-r/2, y-r/3, r/2, SSD1306_WHITE);
    display.fillCircle(x+r/2, y-r/3, r/2, SSD1306_WHITE);
    display.fillTriangle(x-r, y-r/8, x+r, y-r/8, x, y+r, SSD1306_WHITE);
  } else {
    display.drawCircle(x-r/2, y-r/3, r/2, SSD1306_WHITE);
    display.drawCircle(x+r/2, y-r/3, r/2, SSD1306_WHITE);
    display.drawLine(x-r, y-r/8, x, y+r, SSD1306_WHITE);
    display.drawLine(x+r, y-r/8, x, y+r, SSD1306_WHITE);
    display.drawLine(x-r, y-r/8, x+r, y-r/8, SSD1306_WHITE);
  }
}

void drawPerson(int x, int y, bool facingRight) {
  display.drawCircle(x, y, 5, SSD1306_WHITE);
  display.drawLine(x, y+5, x, y+22, SSD1306_WHITE);
  display.drawLine(x, y+10, x-7, y+17, SSD1306_WHITE);
  display.drawLine(x, y+10, x+7, y+17, SSD1306_WHITE);
  display.drawLine(x, y+22, x-6, y+31, SSD1306_WHITE);
  display.drawLine(x, y+22, x+6, y+31, SSD1306_WHITE);
  if (facingRight) display.drawPixel(x+2, y-1, SSD1306_WHITE);
  else display.drawPixel(x-2, y-1, SSD1306_WHITE);
}

void sceneIntro(uint32_t t) {
  centeredText("ATTENTION", 8, 2);
  centeredText("an OLED story", 31, 1);
  drawHeart(64, 52, 10 + (int)(3*sin(t/220.0)), false);
  for (int i=0; i<8; i++) {
    int x = (i*19 + (t/30)%128) % 128;
    display.drawPixel(x, (i*11+5)%60, SSD1306_WHITE);
  }
}

void sceneMemory(uint32_t t) {
  centeredText("OLD MEMORIES", 2);
  // Photograph frame
  display.drawRoundRect(37, 15, 54, 39, 3, SSD1306_WHITE);
  display.drawRect(42, 20, 44, 28, SSD1306_WHITE);
  drawPerson(57, 26, true);
  drawPerson(72, 26, false);
  // drifting memory sparkles
  for (int i=0; i<5; i++) {
    int x = (i*27 + (t/35)%128) % 128;
    display.drawPixel(x, 12 + (i*7)%43, SSD1306_WHITE);
  }
}

void scenePerfume(uint32_t t) {
  centeredText("A FAMILIAR SCENT", 2);
  // Bottle
  display.drawRoundRect(48, 23, 32, 34, 4, SSD1306_WHITE);
  display.drawRect(57, 16, 14, 7, SSD1306_WHITE);
  display.drawRect(60, 12, 8, 4, SSD1306_WHITE);
  display.drawLine(53, 30, 75, 30, SSD1306_WHITE);
  centeredText("~", 16 + (t/180)%4, 1);
  for (int i=0; i<6; i++) {
    int x = 18 + ((i*19 + t/25) % 92);
    int y = 18 + (i*13)%35;
    display.drawPixel(x, y, SSD1306_WHITE);
  }
}

void sceneApart(uint32_t t) {
  centeredText("DRIFTING APART", 2);
  int shift = min(34, (int)(t/90));
  drawPerson(44-shift/2, 19, true);
  drawPerson(84+shift/2, 19, false);
  display.drawLine(64, 17, 64, 54, SSD1306_WHITE);
  for (int i=0; i<4; i++) {
    int x = 58 + (i%2)*12;
    int y = 24 + i*8;
    display.drawPixel(x, y, SSD1306_WHITE);
  }
}

void sceneBrokenHeart(uint32_t t) {
  centeredText("HEART IN TWO", 2);
  int bob = (int)(3*sin(t/170.0));
  drawHeart(64, 34+bob, 22, false);
  display.drawLine(65, 16+bob, 59, 27+bob, SSD1306_WHITE);
  display.drawLine(59, 27+bob, 67, 34+bob, SSD1306_WHITE);
  display.drawLine(67, 34+bob, 60, 45+bob, SSD1306_WHITE);
  display.drawLine(60, 45+bob, 64, 54+bob, SSD1306_WHITE);
}

void sceneAttention(uint32_t t) {
  centeredText("ATTENTION", 2, 2);
  int pulse = (int)(5 + 3*sin(t/130.0));
  display.drawCircle(64, 39, 12+pulse, SSD1306_WHITE);
  display.drawCircle(64, 39, 19+pulse, SSD1306_WHITE);
  drawHeart(64, 39, 10, true);
  for (int i=0; i<8; i++) {
    float a = (t/250.0) + i*0.785;
    int x = 64 + (int)(29*cos(a));
    int y = 39 + (int)(22*sin(a));
    display.drawPixel(x, y, SSD1306_WHITE);
  }
}

void sceneFinal(uint32_t t) {
  centeredText("MOVE ON", 5, 2);
  drawHeart(64, 37, 18, false);
  display.drawLine(64, 18, 64, 55, SSD1306_WHITE);
  centeredText("YOUR STORY CONTINUES", 57, 1);
  if ((t/350)%2 == 0) display.drawPixel(12, 12, SSD1306_WHITE);
  else display.drawPixel(116, 12, SSD1306_WHITE);
}

void setup() {
  Wire.begin(SDA_PIN, SCL_PIN);
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    while (true) delay(100);
  }
  display.clearDisplay();
  display.setTextWrap(false);
  centeredText("ESP32 OLED", 25, 1);
  display.display();
  delay(900);
  sceneStart = millis();
}

void loop() {
  uint32_t now = millis();
  if (now - lastFrame < FRAME_MS) return;
  lastFrame = now;

  uint32_t elapsed = now - sceneStart;
  if (elapsed >= SCENE_DURATION) {
    scene = (scene + 1) % 7;
    sceneStart = now;
    elapsed = 0;
  }

  display.clearDisplay();
  switch (scene) {
    case 0: sceneIntro(elapsed); break;
    case 1: sceneMemory(elapsed); break;
    case 2: scenePerfume(elapsed); break;
    case 3: sceneApart(elapsed); break;
    case 4: sceneBrokenHeart(elapsed); break;
    case 5: sceneAttention(elapsed); break;
    default: sceneFinal(elapsed); break;
  }
  display.display();
}
