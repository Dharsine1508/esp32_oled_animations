# ATTENTION — ESP32 OLED Animation

## Hardware
- ESP32 Dev Module
- 0.96-inch I2C OLED, SSD1306, 128x64
- Jumper wires

## Wiring
| OLED | ESP32 |
|---|---|
| VCC | 3V3 |
| GND | GND |
| SDA | GPIO 21 |
| SCL | GPIO 22 |

Most 0.96-inch SSD1306 modules use I2C address `0x3C`. If your display stays blank, check whether your module uses `0x3D`.

## Arduino IDE setup
1. Install the ESP32 board package and select **ESP32 Dev Module**.
2. Install **Adafruit GFX Library**.
3. Install **Adafruit SSD1306**.
4. Open `Attention_ESP32.ino`, select the correct COM/USB port, and upload.

## Animation
The project loops through seven original scenes: title, memory/photo, perfume bottle, two people moving apart, broken heart, attention pulse, and a closing message. It is a visual interpretation of the song's themes and intentionally does not print the supplied song lyrics.

## Notes
- Default I2C pins are GPIO 21 (SDA) and GPIO 22 (SCL) for a common ESP32 DevKit.
- Change `SDA_PIN`, `SCL_PIN`, or `OLED_ADDR` near the top of the sketch if your board/display differs.
- Change `SCENE_DURATION` to adjust how long each scene lasts.
